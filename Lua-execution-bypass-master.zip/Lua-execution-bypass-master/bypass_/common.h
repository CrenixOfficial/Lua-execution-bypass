#pragma once
#include <Windows.h>
#include <string>
#include <thread>