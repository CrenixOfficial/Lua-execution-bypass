# Lua-execution-bypass
# **Note that it's only made for educational purposes.** 

if your braindead ask from others:
https://discord.gg/C4BjKt2ZX3

Set your luas to C:\Test\test.lua inject the dll with dll injector before joining server and it'll automatically execute your lua file at startup

![](https://i.imgur.com/0a73xRP.png)
